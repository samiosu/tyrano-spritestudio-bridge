# Tyrano SpriteStudio Bridge v0.1.0

ティラノスクリプトV6でSpriteStudioの変換済みSSFBを再生する非公式プラグインです。

- 読み込み・表示・モーション切り替え・ループ再生・再生終了待ち
- 一時停止・再開・停止・位置や透明度の変更・複数表示
- セーブ・ロード復元
- 独自の図形サンプルと日本語の導入手順・タグリファレンス

作者：**さみおす**。連携コードと独自サンプルは **MIT License** です。
依存ライブラリのライセンスは配布物に同梱しています。
個別サポート・導入支援は提供しません。
GitHubのIssue・Pull Requestには対応する場合があります。返信・対応は保証しません。

利用者向けは `tyrano-spritestudio-0.1.0.zip`、ビルド用ソースを含むものは
`tyrano-spritestudio-0.1.0-source.zip` です。ハッシュは `SHA256SUMS.txt` で確認できます。
導入時はZIP内のREADME.mdを参照してください。

ティラノスクリプト **V603b**、Chromium **154** のHTTP配信環境で、
再生・複数表示・セーブ／ロード・メッシュ／ボーンを検証しました。
Safari、Firefox、スマートフォン実機、ティラノスタジオや各OS向けの
パッケージ化は未検証です。SpriteStudioの制作データはSs6ConverterでSSFBへ変換してください。
